import React from 'react';
import { Heart, Leaf, Users, Award } from 'lucide-react';

interface ExtraCurricularProps {
  isDark: boolean;
}

const ExtraCurricular: React.FC<ExtraCurricularProps> = ({ isDark }) => {
  const activities = [
    {
      icon: <Users className="text-blue-600" size={24} />,
      title: "Community Service",
      description: "Actively served in NSS; contributed to community service and social initiatives during academics"
    },
    {
      icon: <Leaf className="text-green-600" size={24} />,
      title: "Environmental Initiatives",
      description: "Participated in Swachh Bharat Abhiyan, cleanliness and environmental drives"
    },
    {
      icon: <Heart className="text-red-600" size={24} />,
      title: "Health & Awareness Campaigns",
      description: "Assisted in health camps, blood donation, and awareness campaigns (digital literacy, gender equality)"
    },
    {
      icon: <Leaf className="text-green-600" size={24} />,
      title: "Environmental Conservation",
      description: "Contributed to tree plantation and rural outreach promoting civic responsibility"
    }
  ];

  return (
    <section className={`py-16 ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Extra-Curricular Activities
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'} max-w-2xl mx-auto`}>
            National Service Scheme (NSS) contributions and community involvement (2022–2024)
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {activities.map((activity, index) => (
              <div
                key={index}
                className={`p-6 rounded-xl transition-all duration-300 hover:shadow-lg hover:scale-105 ${
                  isDark ? 'bg-gray-900 border border-gray-700' : 'bg-gray-50 border border-gray-200'
                }`}
              >
                <div className="flex items-center mb-4">
                  {activity.icon}
                  <h3 className={`text-lg font-semibold ml-3 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                    {activity.title}
                  </h3>
                </div>
                <p className={`${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                  {activity.description}
                </p>
              </div>
            ))}
          </div>

          <div className={`mt-8 p-6 rounded-xl text-center ${isDark ? 'bg-gray-900 border border-gray-700' : 'bg-gradient-to-r from-blue-50 to-purple-50 border border-gray-200'}`}>
            <div className="flex justify-center mb-4">
              <Award className="text-yellow-600" size={32} />
            </div>
            <h3 className={`text-xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              NSS Volunteer Recognition
            </h3>
            <p className={`${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              Dedicated service in National Service Scheme contributing to social welfare and community development initiatives
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExtraCurricular;