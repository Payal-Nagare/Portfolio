import React from 'react';
import { Heart } from 'lucide-react';

interface FooterProps {
  isDark: boolean;
}

const Footer: React.FC<FooterProps> = ({ isDark }) => {
  return (
    <footer className={`py-8 ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-t`}>
      <div className="container mx-auto px-4">
        <div className="text-center">
          <p className={`flex items-center justify-center ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Made with <Heart className="text-red-500 mx-2" size={16} fill="currentColor" /> by Payal Nagare
          </p>
          <p className={`mt-2 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            © 2025 Payal Nagare. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;