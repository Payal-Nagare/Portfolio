import React from 'react';
import { ExternalLink, Calendar, Code } from 'lucide-react';

interface ProjectsProps {
  isDark: boolean;
}

const Projects: React.FC<ProjectsProps> = ({ isDark }) => {
  const projects = [
    {
      title: "Restaurant Data Analysis",
      date: "Mar 2025",
      technologies: ["Python", "Pandas", "Matplotlib", "Seaborn"],
      description: "Conducted EDA on Zomato dataset to uncover trends in online orders, pricing, and restaurant preferences.",
      highlights: [
        "Identified that most cafes offer online delivery and have higher ratings versus dine-in restaurants",
        "Visualized trends with histograms, box plots, and heatmaps"
      ]
    },
    {
      title: "Comprehensive Restaurant Insights Analysis",
      date: "Sep 2024",
      technologies: ["Python", "Pandas", "Matplotlib", "Seaborn", "Plotly", "GeoPandas"],
      description: "Led multi-angle service trend analysis: cuisine popularity, city ratings, and vote distributions.",
      highlights: [
        "Used geospatial mapping for cluster detection and geographic analysis",
        "Explored price, delivery, and review sentiment for actionable insights"
      ]
    },
    {
      title: "AI-Based Mock Interview Evaluator",
      date: "May 2024",
      technologies: ["Python", "OpenCV", "NLP", "Flask"],
      description: "Built an AI-driven tool to assess mock interviews based on emotion, confidence, and knowledge.",
      highlights: [
        "Implemented computer vision and NLP for realistic simulations",
        "Automated feedback system for interview improvement"
      ]
    }
  ];

  return (
    <section id="projects" className={`py-16 ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Featured Projects
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'} max-w-2xl mx-auto`}>
            Showcasing data analysis and machine learning projects with real-world impact
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className={`p-6 rounded-xl transition-all duration-300 hover:shadow-xl hover:scale-105 ${
                isDark ? 'bg-gray-900 border border-gray-700' : 'bg-gray-50 border border-gray-200'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg">
                  <Code className="text-white" size={20} />
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Calendar size={14} className="mr-1" />
                  {project.date}
                </div>
              </div>

              <h3 className={`text-xl font-bold mb-3 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                {project.title}
              </h3>

              <p className={`text-sm mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                {project.description}
              </p>

              <ul className="space-y-2 mb-4">
                {project.highlights.map((highlight, highlightIndex) => (
                  <li key={highlightIndex} className="flex items-start">
                    <span className="w-1.5 h-1.5 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                      {highlight}
                    </span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-wrap gap-2">
                {project.technologies.map((tech, techIndex) => (
                  <span
                    key={techIndex}
                    className={`px-3 py-1 text-xs rounded-full ${
                      isDark ? 'bg-gray-800 text-blue-400' : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;