import React from 'react';
import { Code, Database, BarChart3, PenTool as Tool, Brain, MessageSquare, Globe } from 'lucide-react';

interface SkillsProps {
  isDark: boolean;
}

const Skills: React.FC<SkillsProps> = ({ isDark }) => {
  const skillCategories = [
    {
      icon: <Code className="text-blue-600" size={24} />,
      title: "Programming & Query Languages",
      skills: ["Python (Pandas, NumPy, Matplotlib, Seaborn)", "SQL (Joins, CTEs, Window Functions)"]
    },
    {
      icon: <Database className="text-purple-600" size={24} />,
      title: "Data Analysis & Cleaning",
      skills: ["Excel (VLOOKUP, Pivot Tables, Power Query)", "Pandas", "NumPy"]
    },
    {
      icon: <BarChart3 className="text-teal-600" size={24} />,
      title: "Data Visualization",
      skills: ["Power BI (DAX, Data Modeling)", "Tableau", "Matplotlib", "Seaborn"]
    },
    {
      icon: <Database className="text-green-600" size={24} />,
      title: "Databases & Storage",
      skills: ["MySQL"]
    },
    {
      icon: <Tool className="text-orange-600" size={24} />,
      title: "Tools & Platforms",
      skills: ["Jupyter Notebook", "VS Code", "Git/GitHub", "Excel", "Google Sheets", "Colab"]
    },
    {
      icon: <Brain className="text-pink-600" size={24} />,
      title: "Statistical & Analytical Skills",
      skills: ["Descriptive Statistics", "Hypothesis Testing", "A/B Testing", "Linear Regression", "Forecasting"]
    },
    {
      icon: <MessageSquare className="text-indigo-600" size={24} />,
      title: "Soft Skills",
      skills: ["Strong problem-solving", "Storytelling with Data", "Cross-functional communication", "Business Acumen"]
    },
    {
      icon: <Globe className="text-red-600" size={24} />,
      title: "Languages",
      skills: ["English (Professional)", "Hindi (Fluent)"]
    }
  ];

  return (
    <section id="skills" className={`py-16 ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Technical Skills
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'} max-w-2xl mx-auto`}>
            Comprehensive expertise in data analysis, visualization, and business intelligence
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className={`p-6 rounded-xl transition-all duration-300 hover:shadow-lg hover:scale-105 ${
                isDark ? 'bg-gray-900 border border-gray-700' : 'bg-gray-50 border border-gray-200'
              }`}
            >
              <div className="flex items-center mb-4">
                {category.icon}
                <h3 className={`text-lg font-semibold ml-3 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  {category.title}
                </h3>
              </div>
              <ul className="space-y-2">
                {category.skills.map((skill, skillIndex) => (
                  <li
                    key={skillIndex}
                    className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'} flex items-start`}
                  >
                    <span className="w-2 h-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    {skill}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;