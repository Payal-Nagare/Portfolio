import React from 'react';
import { Briefcase, Calendar, MapPin } from 'lucide-react';

interface ExperienceProps {
  isDark: boolean;
}

const Experience: React.FC<ExperienceProps> = ({ isDark }) => {
  return (
    <section id="experience" className={`py-16 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 to-purple-50'}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Work Experience
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'} max-w-2xl mx-auto`}>
            Professional experience in data analysis and business intelligence
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className={`p-8 rounded-xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'} shadow-lg`}>
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center">
                <div className="p-3 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg mr-4">
                  <Briefcase className="text-white" size={24} />
                </div>
                <div>
                  <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                    Data Analyst
                  </h3>
                  <p className="text-blue-600 font-semibold text-lg">Agrotmissa Products LLP</p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 mb-6">
              <div className="flex items-center">
                <Calendar className="text-gray-500 mr-2" size={16} />
                <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  Jan 2024 – Present
                </span>
              </div>
              <div className="flex items-center">
                <MapPin className="text-gray-500 mr-2" size={16} />
                <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                  Nashik, Maharashtra
                </span>
              </div>
            </div>

            <ul className="space-y-4">
              {[
                "Led comprehensive data analysis across sales, inventory, and customer operations; enabled leadership to make faster, data-backed decisions.",
                "Developed and automated reporting systems with Excel, Python, and Power BI, saving 10+ hours/week.",
                "Collaborated with company directors to resolve business bottlenecks, resulting in 15% improvement in inventory turnover and better resource planning.",
                "Built real-time dashboards and KPIs to drive a data-first culture.",
                "Developed tools for process automation and recruitment analysis; supported identifying team gaps and scaling strategies.",
                "Entrusted with confidential data impacting revenue operations and market positioning."
              ].map((achievement, index) => (
                <li key={index} className="flex items-start">
                  <span className="w-2 h-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mt-2 mr-4 flex-shrink-0"></span>
                  <span className={`${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                    {achievement}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;