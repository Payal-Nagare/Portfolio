import React from 'react';
import { Mail, MapPin, Linkedin, Github, Globe } from 'lucide-react';

interface HeroProps {
  isDark: boolean;
}

const Hero: React.FC<HeroProps> = ({ isDark }) => {
  return (
    <section id="about" className={`pt-20 pb-16 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 to-purple-50'}`}>
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <h1 className={`text-5xl md:text-6xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Payal Nagare
            </h1>
            <p className="text-2xl md:text-3xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent font-semibold mb-6">
              Data Analyst & Insights Professional
            </p>
            <p className={`text-lg md:text-xl leading-relaxed ${isDark ? 'text-gray-300' : 'text-gray-600'} max-w-3xl mx-auto`}>
              Transforming complex data into actionable business insights. Experienced in Python, SQL, Power BI, and advanced analytics 
              with a proven track record of driving data-driven decision making.
            </p>
          </div>

          {/* Contact Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className={`flex items-center justify-center space-x-3 p-4 rounded-lg ${
              isDark ? 'bg-gray-800' : 'bg-white/70'
            } backdrop-blur-sm`}>
              <MapPin className="text-blue-600" size={20} />
              <span className={isDark ? 'text-gray-300' : 'text-gray-700'}>Pune, India</span>
            </div>
            <div className={`flex items-center justify-center space-x-3 p-4 rounded-lg ${
              isDark ? 'bg-gray-800' : 'bg-white/70'
            } backdrop-blur-sm`}>
              <Mail className="text-blue-600" size={20} />
              <span className={isDark ? 'text-gray-300' : 'text-gray-700'}>payal.nagare.33@gmail.com</span>
            </div>
          </div>

          {/* Social Links */}
          <div className="flex justify-center space-x-6">
            <a
              href="https://linkedin.com/in/payalnagare"
              target="_blank"
              rel="noopener noreferrer"
              className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${
                isDark 
                  ? 'bg-gray-800 text-blue-400 hover:bg-blue-600 hover:text-white' 
                  : 'bg-white text-blue-600 hover:bg-blue-600 hover:text-white'
              } shadow-lg`}
            >
              <Linkedin size={24} />
            </a>
            <a
              href="https://github.com/payalnagare"
              target="_blank"
              rel="noopener noreferrer"
              className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${
                isDark 
                  ? 'bg-gray-800 text-gray-400 hover:bg-gray-600 hover:text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-800 hover:text-white'
              } shadow-lg`}
            >
              <Github size={24} />
            </a>
            <a
              href="https://developers.google.com/profile/u/payalnagare"
              target="_blank"
              rel="noopener noreferrer"
              className={`p-3 rounded-full transition-all duration-300 hover:scale-110 ${
                isDark 
                  ? 'bg-gray-800 text-green-400 hover:bg-green-600 hover:text-white' 
                  : 'bg-white text-green-600 hover:bg-green-600 hover:text-white'
              } shadow-lg`}
            >
              <Globe size={24} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;