import React from 'react';
import { GraduationCap, Calendar, MapPin, Award } from 'lucide-react';

interface EducationProps {
  isDark: boolean;
}

const Education: React.FC<EducationProps> = ({ isDark }) => {
  const education = [
    {
      degree: "Bachelor of Engineering in IT",
      institution: "Matoshri College of Engineering, SPPU",
      location: "Nashik, Maharashtra",
      duration: "Dec 2021 – Jun 2024",
      grade: "CGPA 8.45"
    },
    {
      degree: "Diploma in Information Technology",
      institution: "Government Polytechnic, MSBTE",
      location: "Nashik, Maharashtra",
      duration: "Sep 2018 – Sep 2021",
      grade: "88.38%"
    }
  ];

  const internships = [
    {
      title: "Data Science Intern",
      company: "Bharat Intern (Remote)",
      duration: "Jan 2024 – Feb 2024",
      responsibilities: [
        "Conducted EDA, model building, and data visualization on real-world datasets",
        "Built data pipelines and predictive models using Python, Pandas, and Scikit-learn"
      ]
    },
    {
      title: "Data Analytics Intern",
      company: "Cognifyz Technologies (Remote)",
      duration: "Nov 2023 – Dec 2023",
      responsibilities: [
        "Analyzed data using Excel and Python for actionable business insights",
        "Created dashboards and reports to aid decision-making"
      ]
    }
  ];

  const achievements = [
    "AWS re/Start Graduate (cloud computing, databases, Linux fundamentals)",
    "AWS Cloud Practitioner Course (Grade A, EduBridge Learning)",
    "Soft Skills & Workplace Training (TCS)",
    "ESDS Software Solution Ltd. Internship (enterprise IT operations)",
    "Java Backend Development Program (Revature)",
    "Java Training at Besant Technologies"
  ];

  return (
    <section id="education" className={`py-16 ${isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-blue-50 to-purple-50'}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className={`text-4xl font-bold mb-4 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Education & Certifications
          </h2>
          <p className={`text-lg ${isDark ? 'text-gray-300' : 'text-gray-600'} max-w-2xl mx-auto`}>
            Academic background and professional development journey
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Education */}
          <div className="mb-12">
            <h3 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Education
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {education.map((edu, index) => (
                <div
                  key={index}
                  className={`p-6 rounded-xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'} shadow-lg`}
                >
                  <div className="flex items-center mb-4">
                    <div className="p-3 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg mr-4">
                      <GraduationCap className="text-white" size={24} />
                    </div>
                    <div>
                      <h4 className={`text-lg font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                        {edu.degree}
                      </h4>
                      <p className="text-blue-600 font-semibold">{edu.institution}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Calendar className="text-gray-500 mr-2" size={16} />
                      <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                        {edu.duration}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="text-gray-500 mr-2" size={16} />
                      <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                        {edu.location}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Award className="text-gray-500 mr-2" size={16} />
                      <span className={`text-sm font-semibold ${isDark ? 'text-green-400' : 'text-green-600'}`}>
                        {edu.grade}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Internships */}
          <div className="mb-12">
            <h3 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Internships
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {internships.map((internship, index) => (
                <div
                  key={index}
                  className={`p-6 rounded-xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'} shadow-lg`}
                >
                  <h4 className={`text-lg font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
                    {internship.title}
                  </h4>
                  <p className="text-blue-600 font-semibold mb-2">{internship.company}</p>
                  <p className={`text-sm mb-4 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    {internship.duration}
                  </p>
                  
                  <ul className="space-y-2">
                    {internship.responsibilities.map((responsibility, respIndex) => (
                      <li key={respIndex} className="flex items-start">
                        <span className="w-1.5 h-1.5 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                        <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                          {responsibility}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Achievements & Certifications */}
          <div>
            <h3 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Achievements & Certifications
            </h3>
            <div className={`p-6 rounded-xl ${isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200'} shadow-lg`}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className="flex items-start">
                    <span className="w-2 h-2 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    <span className={`${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                      {achievement}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;